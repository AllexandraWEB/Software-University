async function getInfo() {
    const inputRef = document.getElementById("stopId");
    const stopNameRef = document.getElementById("stopName");
    const busInfoRef = document.getElementById("buses");
    const url = `http://localhost:3030/jsonstore/bus/businfo/`

    const stopId = inputRef.value;

    if (!stopId) {
        return;
    }

    inputRef.value = "";
    busInfoRef.textContent = "";

    try {
        const response = await fetch(url + stopId)

        if (!response.ok) {
            stopNameRef.textContent = "Error";
        }

        const data = await response.json();

        stopNameRef.textContent = data.name;
        Object.entries(data.buses).forEach(bus => {
            const li = document.createElement("li");
            li.textContent = `Bus ${bus[0]} arrives in ${bus[1]} minutes`;
            busInfoRef.appendChild(li);
        });
    } catch {
        stopNameRef.textContent = "Error";
    }
}